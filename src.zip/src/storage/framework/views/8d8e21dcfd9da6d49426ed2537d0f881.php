

<?php $__env->startComponent('mail::message'); ?>
    
    <?php $__env->slot('header'); ?>
        <?php $__env->startComponent('mail::header', ['url' => config('app.url')]); ?>
            <!-- header here -->
        <?php echo $__env->renderComponent(); ?>
    <?php $__env->endSlot(); ?>

    
# Richiesta di contatto
<?php echo e($email_body); ?>




A presto,<br>
<?php echo e(config('app.name')); ?>

    


    
    
<?php echo $__env->renderComponent(); ?>

<?php /**PATH /var/www/html/resources/views/emails/contact.blade.php ENDPATH**/ ?>