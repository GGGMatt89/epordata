<!-- Partner -->
<section class="py-5">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-md-3 col-sm-6">
          <a href="https://www.wolterskluwer.it/" target="_blank">
            <img class="img-fluid d-block mx-auto" src="/img/main_home/partner_logos/WK.png" alt="">
          </a>
        </div>
        <div class="col-md-3 col-sm-6">
          <a href="https://www.ipsoa.it/" target="_blank">
            <img class="img-fluid d-block mx-auto" src="/img/main_home/partner_logos/ipsoa.png" alt="">
          </a>
        </div>
        <div class="col-md-3 col-sm-6">
          <a href="https://https://www.mercury-auctions.com/it_it/index/" target="_blank">
            <img class="img-fluid d-block mx-auto" src="/img/main_home/partner_logos/mercuryLogo.png" alt="">
          </a>
        </div>
        <!-- <div class="col-md-3 col-sm-6">
          <a href="https://www.remarketingmachine.com/it/index.htm" target="_blank">
            <img class="img-fluid d-block mx-auto" src="img/logos/remarketingMachine.png" alt="">
          </a>
        </div> -->
      </div>
    </div>
  </section>
<?php /**PATH /Volumes/MattWorkSSD/FLUMENS_techlab/websites/EPORDATA_webapp/epordata/epordataUPGRADE/epordataWebApp/resources/views/home_views/body-sec-partners.blade.php ENDPATH**/ ?>