<?php $__env->startSection('main_content_page'); ?>
    <div class="jumbotron" style="width: 80%; margin: auto; padding: 10px;">
      <div class="container">
          <div class='row'>
                <div class='col-12 col-lg-9'>
                    <h3 class="section_title"><?php echo e($product->name); ?></h3>
                </div>
                <div class='col-3 col-lg-1 mx-auto'>
                   <a role="button" class="btn btn-dark-green-out btn-tooltip" data-toggle="tooltip" data-placement="bottom" title="Vedi clienti" href="<?php echo e(route('purchase.index', ["product_id"=>$product->id])); ?>"><i class="fas fa-shopping-cart"></i></a>
                </div>
                <div class='col-3 col-lg-1 mx-auto'>
                   <a role="button" class="btn btn-dark-blue-out btn-tooltip" data-toggle="tooltip" data-placement="bottom" title="Modifica" href="<?php echo e(route('product.edit', $product->id)); ?>"><i class="far fa-edit"></i></a>
                </div>
                <div class='col-3 col-lg-1 mx-auto'>
                    <form class='delete_form' id='<?php echo e($product->id); ?>_delete_form' action="<?php echo e(route('product.delete', $product->id)); ?>" method="post">
                        <?php echo method_field('DELETE'); ?>
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-primary btn-tooltip" data-toggle="tooltip" data-placement="bottom" title="Elimina" type="button" onclick='deleteEntry(<?php echo e($product->id); ?>)'><i class="far fa-trash-alt"></i></button>
                    </form>
                </div>
            </div>
            <div class='row d-flex justify-content-center'>
                <hr class='show-sep'>
            </div>
            <div class='row'>
                <div class="form-group col-12 col-md-4">
                      <p class="lead lead-in">Codice prodotto: </p>
                  </div>
                <div class="form-group col-12 col-md-8">
                    <p class="lead"><?php echo e($product->code); ?></p>
                </div>
            </div>
            <div class='row'>
                <div class="form-group col-12 col-md-4 col-lg-2">
                    <p class="lead lead-in">Tipo: </p>
                </div>
                <div class="form-group col-12 col-md-8 col-lg-4">
                    <p class="lead"><?php echo e($product->type); ?></p>
                </div>
                <div class="form-group col-12 col-md-4 col-lg-2">
                    <p class="lead lead-in">Categoria: </p>
                </div>
                <div class="form-group col-12 col-md-8 col-lg-4">
                    <p class="lead"><?php echo e($product->category); ?></p>
                </div>
            </div>
            <div class='row'>
                <div class="form-group col-12 col-md-4">
                    <p class="lead lead-in">Fornito da: </p>
                </div>
                <div class="form-group col-12 col-md-8">
                    <p class="lead"><?php echo e($product->provider_name); ?></p>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.db', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/db_views/product/show.blade.php ENDPATH**/ ?>