<?php $__env->startSection('main_content_page'); ?>
  <div class='row'>
    <div class='col-12'>
      <h3 class='section_title'>Nuovo cliente</h3>
      <hr class='styled-hr'>
      <form method='POST' action='<?php echo e(route("customer.store")); ?>'>
        <?php echo csrf_field(); ?>
        <div class='form-row'>
          <div class="form-group col-12 col-md-6">
            <label class='db_form_label' for="cus_code">Codice cliente</label>
            <input type="text" class="form-control <?php echo e($errors->has('cus_code') ? 'form-error' : ''); ?>" name="cus_code" id="cus_code" value="<?php echo e(old('cus_code')); ?>" placeholder="Codice cliente">
            <?php $__errorArgs = ['cust_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="error-input"><?php echo e($errors->first('cust_code')); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="form-group col-12 col-md-6">
            <label class='db_form_label' for="univ_code">Codice univoco</label>
            <input type="text" class="form-control <?php echo e($errors->has('univ_code') ? 'form-error' : ''); ?>" name="univ_code" id="univ_code" value="<?php echo e(old('univ_code')); ?>" placeholder="Codice univoco">
            <?php $__errorArgs = ['univ_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="error-input"><?php echo e($errors->first('univ_code')); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>
        <div class='form-row'>
          <div class="form-group col-12 col-md-6">
            <label class='db_form_label' for="first_name">Nome</label>
            <input type="text" class="form-control <?php echo e($errors->has('first_name') ? 'form-error' : ''); ?>" name="first_name" id="first_name" value="<?php echo e(old('first_name')); ?>" placeholder="Nome">
            <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="error-input"><?php echo e($errors->first('first_name')); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="form-group col-12 col-md-6">
            <label class='db_form_label' for="last_name">Cognome</label>
            <input type="text" class="form-control <?php echo e($errors->has('last_name') ? 'form-error' : ''); ?>" name="last_name" id="last_name" value="<?php echo e(old('last_name')); ?>" placeholder="Cognome">
            <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="error-input"><?php echo e($errors->first('last_name')); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>
        <div class='form-row'>
          <div class="form-group col-12 col-md-6">
            <label class='db_form_label' for="title">Titolo</label>
            <input type="text" class="form-control <?php echo e($errors->has('title') ? 'form-error' : ''); ?>" name="title" id="title" value="<?php echo e(old('title')); ?>" placeholder="Titolo">
            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="error-input"><?php echo e($errors->first('title')); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="form-group col-12 col-md-6">
            <label class='db_form_label' for="bus_name">Ragione sociale</label>
            <input type="text" class="form-control <?php echo e($errors->has('bus_name') ? 'form-error' : ''); ?>" name="bus_name" id="bus_name" value="<?php echo e(old('bus_name')); ?>" placeholder="Ragione sociale">
            <?php $__errorArgs = ['bus_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="error-input"><?php echo e($errors->first('bus_name')); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>
        <div class='form-row'>
          <div class="form-group col-12 col-md-6">
            <label class='db_form_label' for="tax_code">Codice fiscale</label>
            <input type="text" class="form-control <?php echo e($errors->has('tax_code') ? 'form-error' : ''); ?>" name="tax_code" id="tax_code" value="<?php echo e(old('tax_code')); ?>" placeholder="Codice fiscale">
            <?php $__errorArgs = ['tax_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="error-input"><?php echo e($errors->first('tax_code')); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="form-group col-12 col-md-6">
            <label class='db_form_label' for="vat_num">Partita IVA</label>
            <input type="text" class="form-control <?php echo e($errors->has('vat_num') ? 'form-error' : ''); ?>" name="vat_num" id="vat_num" value="<?php echo e(old('vat_num')); ?>" placeholder="Partita IVA">
            <?php $__errorArgs = ['vat_num'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="error-input"><?php echo e($errors->first('vat_num')); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>
        <div class='form-row'>
          <div class="form-group col-12 col-md-6">
            <label class='db_form_label' for="email">Email</label>
            <input type="text" class="form-control <?php echo e($errors->has('email') ? 'form-error' : ''); ?>" name="email" id="email" value="<?php echo e(old('email')); ?>" placeholder="Email">
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="error-input"><?php echo e($errors->first('email')); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="form-group col-12 col-md-6">
            <label class='db_form_label' for="pec">PEC</label>
            <input type="text" class="form-control <?php echo e($errors->has('pec') ? 'form-error' : ''); ?>" name="pec" id="pec" value="<?php echo e(old('pec')); ?>" placeholder="PEC">
            <?php $__errorArgs = ['pec'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="error-input"><?php echo e($errors->first('pec')); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>
        <div class='form-row'>
          <div class="form-group col-12 col-md-6">
            <label class='db_form_label' for="office_phone"><i class="fas fa-phone"></i> ufficio</label>
            <input type="text" class="form-control <?php echo e($errors->has('office_phone') ? 'form-error' : ''); ?>" name="office_phone" id="office_phone" value="<?php echo e(old('office_phone')); ?>" placeholder="Telefono ufficio">
            <?php $__errorArgs = ['office_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="error-input"><?php echo e($errors->first('office_phone')); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="form-group col-12 col-md-6">
            <label class='db_form_label' for="mobile_phone"><i class="fas fa-mobile-alt"></i> cellulare</label>
            <input type="text" class="form-control <?php echo e($errors->has('mobile_phone') ? 'form-error' : ''); ?>" name="mobile_phone" id="mobile_phone" value="<?php echo e(old('mobile_phone')); ?>" placeholder="Telefono cellulare">
            <?php $__errorArgs = ['mobile_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="error-input"><?php echo e($errors->first('mobile_phone')); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>
        <div class='form-row'>
          <div class="form-group col-12 col-md-8">
            <label class='db_form_label' for="address">Indirizzo</label>
            <input type="text" class="form-control <?php echo e($errors->has('address') ? 'form-error' : ''); ?>" name="address" id="address" value="<?php echo e(old('address')); ?>" placeholder="Indirizzo">
            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="error-input"><?php echo e($errors->first('address')); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="form-group col-12 col-md-4">
            <label class='db_form_label' for="post_code">Codice postale</label>
            <input type="text" class="form-control <?php echo e($errors->has('post_code') ? 'form-error' : ''); ?>" name="post_code" id="post_code" value="<?php echo e(old('post_code')); ?>" placeholder="Codice postale">
            <?php $__errorArgs = ['post_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="error-input"><?php echo e($errors->first('post_code')); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>
        <div class='form-row'>
          <div class="form-group col-12 col-md-6">
            <label class='db_form_label' for="city">Città</label>
            <input type="text" class="form-control <?php echo e($errors->has('city') ? 'form-error' : ''); ?>" name="city" id="city" value="<?php echo e(old('city')); ?>" placeholder="Città">
            <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="error-input"><?php echo e($errors->first('city')); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="form-group col-12 col-md-6">
            <label class='db_form_label' for="region">Provincia</label>
            <input type="text" class="form-control <?php echo e($errors->has('region') ? 'form-error' : ''); ?>" name="region" id="region" value="<?php echo e(old('region')); ?>" placeholder="Regione">
            <?php $__errorArgs = ['region'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="error-input"><?php echo e($errors->first('region')); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>
        <div class='form-row'>
          <div class="form-group col-12 col-md-6">
            <label class='db_form_label' for="category">Categoria</label>
            <select class="selectpicker show-tick form-control <?php echo e($errors->has('category') ? 'form-error' : ''); ?>" data-size="5" id="category" name="category" value="<?php echo e(old('category')); ?>">
              <option value=" " selected>Seleziona categoria cliente</option>
              <option data-divider="true"></option>
              <?php
                $selected_cat = $errors->any() ? old('category') : ' ';
              ?>
              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value=<?php echo e($category); ?> <?php echo e($selected_cat == $category ? 'selected' : ''); ?>><?php echo e($category); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="error-input"><?php echo e($errors->first('category')); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="form-group col-12 col-md-6">
            <label class='db_form_label' for="handler">Curatore</label>
            <select class="selectpicker show-tick form-control <?php echo e($errors->has('handler') ? 'form-error' : ''); ?>" data-size="5" id="handler" name="handler" value="<?php echo e(old('handler')); ?>">
              <option value=" " selected>Seleziona curatore cliente</option>
              <option data-divider="true"></option>
              <?php
                $selected_hand = $errors->any() ? old('handler') : ' ';
              ?>
              <?php $__currentLoopData = $handlers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $handler): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value=<?php echo e($handler); ?> <?php echo e($selected_hand == $handler ? 'selected' : ''); ?>><?php echo e($handler); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['handler'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="error-input"><?php echo e($errors->first('handler')); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>
        <div class='form-row'>
          <div class="form-group col-12">
            <label class='db_form_label' for="rating">Rating</label>
            <select class="selectpicker show-tick form-control <?php echo e($errors->has('rating') ? 'form-error' : ''); ?>" data-size="5" id="rating" name="rating" value="<?php echo e(old('rating')); ?>">
              <option value=" " selected>Seleziona rating cliente</option>
              <option data-divider="true"></option>
              <?php
                $selected_rat = $errors->any() ? old('rating') : ' ';
              ?>
              <?php $__currentLoopData = $ratings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rating): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value=<?php echo e($rating); ?> <?php echo e($selected_rat == $rating ? 'selected' : ''); ?>><?php echo e($rating); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['rating'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="error-input"><?php echo e($errors->first('rating')); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>
        <div class='form-row'>
          <div class="form-group col-12">
            <label class='db_form_label' for="profile_id">Agente di riferimento</label>
            <select class="selectpicker show-tick  form-control <?php echo e($errors->has('profile_id') ? 'form-error' : ''); ?>" data-size="5" name="profile_id" id="profile_id" value="<?php echo e(old('profile_id')); ?>" data-live-search="true">
              <option value=' ' selected>Selezione agente di riferimento</option>
              <option data-divider="true"></option>
              <?php
                $selected_prof = $errors->any() ? old('profile_id') : ' ';
              ?>
              <?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value='<?php echo e($profile->id); ?>' <?php echo e($selected_prof == $profile->id ? 'selected' : ''); ?>><?php echo e($profile -> first_name); ?> <?php echo e($profile -> last_name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['profile_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="error-input"><?php echo e($errors->first('profile_id')); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>
        <div id="accordion">
          <div class="card">
            <div class="card-header" id="headingRef">
              <h5 class="mb-0">
              <button type='button' class="btn btn-link" data-toggle="collapse" data-target="#collapseRef" aria-expanded="true" aria-controls="collapseRef">
                <i class="fas fa-chevron-down"></i>  Referente cliente (opzionale)
              </button>
              </h5>
            </div>
            <div id="collapseRef" class="collapse" aria-labelledby="headingRef" data-parent="#accordion">
                <div class="card-body">
                  <div class='form-row'>
                    <div class="form-group col-12 col-md-6">
                      <label class='db_form_label' for="ref_name">Nome</label>
                      <input type="text" class="form-control <?php echo e($errors->has('ref_name') ? 'form-error' : ''); ?>" name="ref_name" id="ref_name" value="<?php echo e(old('ref_name')); ?>" placeholder="Nome">
                      <?php $__errorArgs = ['ref_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="error-input"><?php echo e($errors->first('ref_name')); ?></p>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group col-12 col-md-6">
                      <label class='db_form_label' for="ref_surname">Cognome</label>
                      <input type="text" class="form-control <?php echo e($errors->has('ref_surname') ? 'form-error' : ''); ?>" name="ref_surname" id="ref_surname" value="<?php echo e(old('ref_surname')); ?>" placeholder="Cognome">
                      <?php $__errorArgs = ['ref_surname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="error-input"><?php echo e($errors->first('ref_surname')); ?></p>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                  </div>
                  <div class='form-row'>
                    <div class="form-group col-12">
                      <label class='db_form_label' for="ref_title">Ruolo</label>
                      <input type="text" class="form-control <?php echo e($errors->has('ref_title') ? 'form-error' : ''); ?>" name="ref_title" id="ref_title" value="<?php echo e(old('ref_title')); ?>" placeholder="Ruolo">
                      <?php $__errorArgs = ['ref_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="error-input"><?php echo e($errors->first('ref_title')); ?></p>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group col-5">
                      <label class='db_form_label' for="ref_email"><i class="far fa-envelope"></i> Email</label>
                      <input type="text" class="form-control <?php echo e($errors->has('ref_email') ? 'form-error' : ''); ?>" name="ref_email" id="ref_email" value="<?php echo e(old('ref_email')); ?>" placeholder="Email">
                      <?php $__errorArgs = ['ref_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="error-input"><?php echo e($errors->first('ref_email')); ?></p>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                  </div>
                  <div class='form-row'>
                    <div class="form-group col-12 col-md-6">
                      <label class='db_form_label' for="ref_phone"><i class="fas fa-phone"></i> Ufficio / <i class="fas fa-mobile-alt"></i> Cellulare</label>
                      <input type="text" class="form-control <?php echo e($errors->has('ref_phone') ? 'form-error' : ''); ?>" name="ref_phone" id="ref_phone" value="<?php echo e(old('ref_phone')); ?>" placeholder="Telefono">
                      <?php $__errorArgs = ['ref_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="error-input"><?php echo e($errors->first('ref_phone')); ?></p>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                  </div>
                </div>
            </div>
          </div>
        </div>
      <button type="submit" class="btn btn-primary btn-gradient btn-submit-form">Salva</button>
    </form>
  </div>
</div>
<script>
    $(document).ready(function () {
    $("#collapseRef").on("hide.bs.collapse", function () {
        $(".btn-link").html('<i class="fas fa-chevron-down"></i>  Referente cliente (opzionale)');
    });
    $("#collapseRef").on("show.bs.collapse", function () {
        $(".btn-link").html('<i class="fas fa-chevron-up"></i>  Referente cliente (opzionale)');
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.db', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/db_views/customer/create.blade.php ENDPATH**/ ?>