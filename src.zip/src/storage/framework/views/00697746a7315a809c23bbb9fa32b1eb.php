<?php $__env->startSection('main_content_page'); ?>
    <?php echo $__env->make('db_views.user.db-user-home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.db', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views//db_views/db_home.blade.php ENDPATH**/ ?>