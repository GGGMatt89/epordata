<?php $__env->startSection('main_content_page'); ?>
    <div class='row'>
        <div class='col-12'>
            <?php if(isset($page_title)): ?>
                <h5 class='section_title'><?php echo e($page_title); ?></h5>
            <?php endif; ?>
        </div>
    </div>
    <div class='row'>
        <div class='col-sm-2 col-md-1'>
            <a role="button" class="btn btn-dark-red-out btn-tooltip" data-toggle="tooltip" data-placement="bottom" title="Crea nuovo" href="<?php echo e(route ('participant.create', ["customer_id"=>$customer_id, "lecture_id"=>$lecture_id])); ?>"><i class="fas fa-plus"></i></a>
        </div>
        
    </div>
    <div class='table-responsive' id='participants_table'>
        <table class="table table-hover align-middle">
        <thead>
            <tr class="bg-table-header">
                <th scope="col"><?php echo e($table_title); ?></th>
                <th scope="col">Ruolo</th>
                <th scope="col">Pagato?</th>
                <th scope="col"></th>
                <th scope="col"></th>
                <th scope="col"></th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $participants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <?php if(isset($customer_id)): ?>
                    <th scope="row"><?php echo e($participant->lecture->title); ?></th>
                <?php endif; ?>
                <?php if(isset($lecture_id)): ?>
                    <th scope="row"><?php echo e($participant->last_name); ?> <?php echo e($participant->first_name); ?></th>
                <?php endif; ?>
                <?php if(!isset($customer_id) && !isset($lecture_id)): ?>
                    <th scope="row"><?php echo e($participant->last_name); ?> <br> <?php echo e($participant->lecture->title); ?></th>
                <?php endif; ?>
                <td><?php echo e($participant->role); ?></td>
                <td class=<?php echo e($participant->payed ? 'checked-td' : 'unchecked-td'); ?>>
                <?php if($participant->payed): ?>
                <i class="far fa-check-circle"></i>
                <?php else: ?>
                <i class="far fa-circle"></i>
                <?php endif; ?>
                </td>
                <td><a class = "btn btn-dark-blue btn-tooltip" data-toggle="tooltip" data-placement="bottom" title="Dettagli" href = "<?php echo e(route ('participant.show', $participant->id )); ?>"><i class="far fa-eye"></i></a></td>
                <td><a class = "btn btn-dark-blue-out btn-tooltip" data-toggle="tooltip" data-placement="bottom" title="Modifica" href = "<?php echo e(route ('participant.edit', $participant->id )); ?>"><i class="far fa-edit"></i></a></td>
                <td><form class='delete_form' id='<?php echo e($participant->id); ?>_delete_form' action="<?php echo e(route('participant.delete', $participant->id)); ?>" method="post">
                    <?php echo method_field('DELETE'); ?>
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-primary btn-tooltip" data-toggle="tooltip" data-placement="bottom" title="Elimina" type="button" onclick='deleteEntry(<?php echo e($participant->id); ?>)'><i class="far fa-trash-alt"></i></button>
                    </form>
                </td></tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <th scope="row" colspan="6">Nessun iscritto</th>
                </tr>
            <?php endif; ?>
        </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.db', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/db_views/participant/index.blade.php ENDPATH**/ ?>