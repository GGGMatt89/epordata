<?php $__env->startSection('main_content_page'); ?>
    <div class='row'>
        <div class='col-12'>
            <h3 class='section_title'>Lista clienti</h3>
            <hr class='styled-hr'>
        </div>
    </div>
    <div class='row'>
        <div class='col-sm-2 col-md-1'>
            <a role="button" class="btn btn-dark-blue btn-tooltip" data-toggle="tooltip" data-placement="bottom" title="Aggiungi" href="<?php echo e(route('customer.create')); ?>"><i class="fas fa-plus"></i></a>
        </div>
        <div class='col-sm-9 col-md-11'>
            <div class="accordion filters" id="accordion">
                <div class="accordion-item">
                  <h2 class="accordion-header" id="headingRef">
                    <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseRef" aria-expanded="true" aria-controls="collapseRef">
                        Filtri di ricerca
                    </button>
                  </h2>
                  <div id="collapseRef" class="accordion-collapse collapse" aria-labelledby="headingRef" data-bs-parent="#accordion">
                    <div class="accordion-body">
                        <form method='GET' action='<?php echo e(route("customer.index")); ?>'>
                            <?php echo csrf_field(); ?>
                            <div class='form-row'>
                              <div class="form-group col-12 col-md-6">
                                <label class='db_form_label' for="category">Categoria</label>
                                <select class="selectpicker show-tick form-control" data-size="5" name="category" id="category">
                                  <option value='unselected'>Seleziona categoria cliente</option>
                                  <option data-divider="true"></option>
                                  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category); ?>" <?php echo e($old_cat == $category ? 'selected' : ''); ?>><?php echo e($category); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                              </div>
                              <div class="form-group col-12 col-md-6">
                                <label class='db_form_label' for="handler">Curatore</label>
                                <select class="selectpicker show-tick form-control" data-size="5" id="handler" name="handler">
                                  <option value='unselected'>Seleziona curatore cliente</option>
                                  <option data-divider="true"></option>
                                  <?php $__currentLoopData = $handlers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $handler): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($handler); ?>" <?php echo e($old_handler == $handler ? 'selected' : ''); ?>><?php echo e($handler); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                              </div>
                            </div>
                            <div class='form-row'>
                              <div class="form-group col-12 col-md-4">
                                <label class='db_form_label' for="region">Provincia</label>
                                <select class="selectpicker show-tick form-control" data-size="5" name="region" id="region">
                                  <option value='unselected'>Seleziona provincia cliente</option>
                                  <option data-divider="true"></option>
                                  <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($region); ?>" <?php echo e($old_region == $region ? 'selected' : ''); ?>><?php echo e($region); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                              </div>
                            <div class="form-group col-12 col-md-4">
                                <label class='db_form_label' for="rating">Rating</label>
                                <select class="selectpicker show-tick form-control" data-size="5" id="rating" name="rating">
                                  <option value='unselected'>Seleziona rating cliente</option>
                                  <option data-divider="true"></option>
                                  <?php $__currentLoopData = $ratings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rating): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($rating); ?>" <?php echo e($old_rating == $rating ? 'selected' : ''); ?>><?php echo e($rating); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                              </div>
                            <div class="form-check col-12 col-md-4">
                                <div class="checkbox-container filter-checkbox">
                                    <p class='db_form_label input-title'>Solo personali?</p>
                                    <label class="checkbox-label" for="personal">
                                        <input type="checkbox" name="personal" id="personal" <?php echo e($old_personal ? 'checked' : ''); ?>>
                                        <span class="checkbox-custom rectangular"></span>
                                    </label>
                                </div>
                            </div>
                            </div>
                            <div class='form-row'>
                                <div class='col-2 col-md-2 my-auto'>
                                    <button type="submit" class="btn btn-dark-blue-out"><i class="fas fa-search"></i> Cerca</button>
                                </div>
                            </div>
                            </form>
                        </div>
                  </div>
                </div>
            </div>
        </div>
    </div>
    <div class='table-responsive' id='customers_table'>
        <table class="table table-hover align-middle">
            <thead>
            <tr class="bg-table-header">
            <th scope="col">Cognome</th>
            <th scope="col">Nome</th>
            <th scope="col">Email</th>
            <th scope="col">Città</th>
            <th scope="col"></th>
            <th scope="col"></th>
            <th scope="col"></th>
            <th scope="col"></th>
            <th scope="col"></th>
            </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                <th scope="row"><?php echo e($customer -> last_name); ?></th>
                <td><?php echo e($customer -> first_name); ?></td>
                <td><?php echo e($customer -> email); ?></td>
                <td><?php echo e($customer -> city); ?></td>
                <td><a class = "btn btn-dark-blue btn-tooltip" data-toggle="tooltip" data-placement="bottom" title="Dettagli" href = "<?php echo e(route ('customer.show', $customer -> id )); ?>"><i class="far fa-eye"></i></a></td>
                <td><a class = "btn btn-dark-blue-out btn-tooltip" data-toggle="tooltip" data-placement="bottom" title="Modifica" href = "<?php echo e(route ('customer.edit', $customer -> id )); ?>"><i class="far fa-edit"></i></a></td>
                <td><a class = "btn btn-dark-green-out btn-tooltip" data-toggle="tooltip" data-placement="bottom" title="Crea acquisto" href = "<?php echo e(route ('purchase.create', ["customer_id"=>$customer->id])); ?>"><i class="fas fa-shopping-cart"></i></a></td>
                <td><a class = "btn btn-dark-red-out btn-tooltip" data-toggle="tooltip" data-placement="bottom" title="Iscrivi a corso" href = "<?php echo e(route ('participant.create', ["customer_id"=>$customer->id])); ?>"><i class="fas fa-chalkboard-teacher"></i></a></td>
                
                <td><a class = "btn btn-orange-out btn-tooltip" data-toggle="tooltip" data-placement="bottom" title="Vedi appuntamenti" href = "<?php echo e(route ('customer.listMeetings', $customer -> id )); ?>"><i class="far fa-handshake"></i></a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <th scope="row" colspan="9">Nessun cliente</th>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.db', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/db_views/customer/index.blade.php ENDPATH**/ ?>