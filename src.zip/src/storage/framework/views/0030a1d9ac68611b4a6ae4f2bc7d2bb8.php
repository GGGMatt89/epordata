<?php $__env->startSection('main_content_page'); ?>
    <div class='row'>
        <div class='col-12'>
            <h3 class='section_title'>Lista profili utenti</h3>
            <hr class='styled-hr'>
        </div>
    </div>
    <div class='table-responsive' id='profiles_table'>
        <table class="table table-hover align-middle">
            <thead>
            <tr>
            <th scope="col">Cognome</th>
            <th scope="col">Nome</th>
            <th scope="col">Cellulare</th>
            <th scope="col">Area</th>
            <th scope="col"> </th>
            <th scope="col"> </th>
            <?php if(Auth::user()->auth_level == 'Admin'): ?>
                <th scope="col"> </th>
            <?php endif; ?>
            </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <th scope="row"><?php echo e($profile -> last_name); ?></th>
                    <td><?php echo e($profile -> first_name); ?></td>
                    <td><?php echo e($profile -> mobile_phone); ?></td>
                    <td><?php echo e($profile -> area); ?></td>
                    <td><a class = "btn btn-dark-blue btn-tooltip" data-toggle="tooltip" data-placement="bottom" title="Dettagli" href = "<?php echo e(route ('profile.show', $profile->id )); ?>"><i class="far fa-eye"></i></a></td>
                    <td><a class = "btn btn-dark-blue-out  btn-tooltip" data-toggle="tooltip" data-placement="bottom" title="Modifica" href = "<?php echo e(route ('profile.edit', $profile->id )); ?>"><i class="far fa-edit"></i></a></td>
                    <?php if(Auth::user()->auth_level == 'Admin'): ?>
                        <td><a class = "btn btn-dark-blue-out  btn-tooltip" data-toggle="tooltip" data-placement="bottom" title="Modifica utente" href = "<?php echo e(route ('user.edit', $profile->user->id )); ?>"><i class="fas fa-user-cog"></i></a></td>
                    <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.db', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/db_views/profile/index.blade.php ENDPATH**/ ?>