<!-- Header -->
<header class="masthead">
  <div class="container">
    <div class="intro-text">
      <div>
        <img id="logo_big" src="/img/main_home/epordata_logo.png" class="logo_img img-fluid animated heartBeat">
      </div>
      <div class="intro-lead-in text-uppercase">
        <!-- <span class="txt-rotate" data-period="2000" data-rotate='["Servizi per professionisti e imprese", "Servizi per professionisti e imprese"]'></span> -->
        Servizi per professionisti e imprese
      </div>
      <div class="intro-heading text-uppercase"></div>
        <a class="btn btn-primary btn-xl text-uppercase js-scroll-trigger" href="#services">Scopri di più</a>
      </div>
  </div>
</header>
<?php /**PATH /Volumes/MattWorkSSD/FLUMENS_techlab/websites/EPORDATA_webapp/epordata/epordataUPGRADE/epordataWebApp/resources/views/home_views/body-header.blade.php ENDPATH**/ ?>