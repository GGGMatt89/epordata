<!-- Navigation -->
<nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
    <div class="container">
      <a class="navbar-brand js-scroll-trigger" href="#page-top"><img src="/img/main_home/logo_esteso.png"></a>
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        Menu
        <i class="fas fa-bars"></i>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav text-uppercase ml-auto">
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#services">Servizi</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#products">News</a>
          </li>
          <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#offers">Info & Offerte</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#history">Chi siamo</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#team">Il team</a>
          </li>
          <li class="nav-item">
            <a id='contact-link' class="nav-link js-scroll-trigger" href="#contact">Contattaci</a>
          </li>
          <?php if(Route::has('login')): ?>
              <?php if(auth()->guard()->check()): ?>
              <li class="nav-item dropdown notif">
                
                <a class="nav-link dropdown-toggle user-link" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <mark></mark>
                  <span class="notification-badge  <?php echo e($Nmeeting>0 ? 'd-block' : 'd-none'); ?>"><?php echo e($Nmeeting); ?></span>
                  <span>
                  <?php if(Auth::user()->auth_level == 'Admin'): ?>
                    <i class="fas fa-crown fa-lg"></i>
                  <?php else: ?>
                    <i class="fas fa-user fa-lg"></i>
                  <?php endif; ?>
                  <?php echo e(Auth::user()->name); ?>

                  </span>
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                  <a class="dropdown-item" href="<?php echo e(route('db_home')); ?>">Gestionale</a>
                  
                  <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                      onclick="event.preventDefault();
                      document.getElementById('logout-form').submit();">
                      <?php echo e(__('Logout')); ?> <i class="fas fa-sign-out-alt"></i>
                  </a>
                  <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                      <?php echo csrf_field(); ?>
                  </form>
                </div>
              </li>
              <?php else: ?>
              <li class="nav-item ">
                <a class="nav-link" href="<?php echo e(route('login')); ?>" ><span><i class="fas fa-user fa-lg"></i></span>Area privata</a>
                  
                  
              </li>
              <?php endif; ?>
            </li>
          <?php endif; ?>
        </ul>
      </div>
    </div>
  </nav>
<?php /**PATH /Volumes/MattWorkSSD/FLUMENS_techlab/websites/EPORDATA_webapp/epordata/epordataUPGRADE/epordataWebApp/resources/views/home_views/main-nav.blade.php ENDPATH**/ ?>