<?php $__env->startSection('main_content_page'); ?>
<script src="/js/forms_handling.js" type="module"></script>
  <div class='row'>
    <div class='col-12'>
      <h3 class='section_title'>Nuovo appuntamento</h3>
      <hr class='styled-hr'>
      <form method='POST' action='<?php echo e(route("meeting.store")); ?>'>
        <?php echo csrf_field(); ?>
        <input name="customer_id" id="cust-id" type="hidden">
        <div class="row">
          <div class="form-group col-12">
            <label class='db_form_label' for="cust-select">Cliente</label>
            <select class="selectpicker show-tick form-control" id="cust-select" data-size="5" data-live-search="true">
              <option>Seleziona cliente o aggiungilo manualmente</option>
              <option data-divider="true"></option>
              <?php
                $selected_cid = $errors->any() ? old('customer_id') : '';
              ?>
              <optgroup label="Miei clienti">
                <?php $__currentLoopData = $personal_customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value='<?php echo e($customer->id); ?>' <?php echo e($selected_cid == $customer->id ? 'selected' : ''); ?>><?php echo e($customer->title); ?> <?php echo e($customer->first_name); ?> <?php echo e($customer->last_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </optgroup>
              <optgroup label="Altri clienti">
                  <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value='<?php echo e($customer->id); ?>' <?php echo e($selected_cid == $customer->id ? 'selected' : ''); ?>><?php echo e($customer->title); ?> <?php echo e($customer->first_name); ?> <?php echo e($customer->last_name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </optgroup>
            </select>
          </div>
        </div>
        <div class='row'>
          <div class="form-group col-sm-12 col-md-6">
            <label class='db_form_label' for="cust_name">Nome</label>
            <input type="text" class="form-control <?php echo e($errors->has('cust_name') ? 'form-error' : ''); ?>" name="cust_name" id="cust-name" value="<?php echo e(old('cust_name')); ?>" placeholder="Nome">
            <?php $__errorArgs = ['cust_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="error-input"><?php echo e($errors->first('cust_name')); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="form-group col-sm-12 col-md-6">
            <label class='db_form_label' for="cust_surname">Cognome</label>
            <input type="text" class="form-control <?php echo e($errors->has('cust_surname') ? 'form-error' : ''); ?>" name="cust_surname" id="cust-surname" value="<?php echo e(old('cust_surname')); ?>" placeholder="Cognome">
            <?php $__errorArgs = ['cust_surname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="error-input"><?php echo e($errors->first('cust_surname')); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>
        <div class='row'>
          <div class="form-group col-12 col-md-9">
            <label class='db_form_label' for="meet_address">Indirizzo appuntamento</label>
            <input type="text" class="form-control <?php echo e($errors->has('meet_address') ? 'form-error' : ''); ?>" name="meet_address" id="meet-place" value="<?php echo e(old('meet_address')); ?>" placeholder="Sede appuntamento">
            <?php $__errorArgs = ['meet_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="error-input"><?php echo e($errors->first('meet_address')); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="form-check col-12 col-md-3">
          <div class="checkbox-container">
            <p class='db_form_label input-title'>Remoto/Web?</p>
            <label class="checkbox-label" for="remote">
              <input type="checkbox" class="<?php echo e($errors->has('remote') ? 'form-error' : ''); ?>" name="remote" id="remote" <?php echo e(old('remote') ? 'checked' : ''); ?>>
              <span class="checkbox-custom rectangular"></span>
            </label>
          </div>
          <?php $__errorArgs = ['remote'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="error-input"><?php echo e($errors->first('remote')); ?></p>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        </div>
        <div class='row'>
          <div class="form-group col-sm-12 col-md-6">
            <label class='db_form_label' for="meet_date">Data</label>
            <input type="date" class="form-control <?php echo e($errors->has('meet_date') ? 'form-error' : ''); ?>" name="meet_date" id="meet-date" value="<?php echo e(old('meet_date')); ?>" placeholder="Data">
            <?php $__errorArgs = ['meet_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="error-input"><?php echo e($errors->first('meet_date')); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="form-group col-sm-12 col-md-6">
            <label class='db_form_label' for="meet_time">Ora</label>
            <input type="time" class="form-control <?php echo e($errors->has('meet_time') ? 'form-error' : ''); ?>" name="meet_time" id="meet-time" value="<?php echo e(old('meet_time')); ?>" placeholder="Ora">
            <?php $__errorArgs = ['meet_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="error-input"><?php echo e($errors->first('meet_time')); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>
        <div class='row'>
          <div class="form-group col-sm-12 col-md-6">
            <label class='db_form_label' for="notes">Note/dettagli</label>
            <input type="text" class="form-control <?php echo e($errors->has('notes') ? 'form-error' : ''); ?>" name="notes" id="meet-notes" value="<?php echo e(old('notes')); ?>" placeholder="Note">
            <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="error-input"><?php echo e($errors->first('notes')); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="form-group col-sm-12 col-md-6">
            <label class='db_form_label' for="user-select">Agente</label>
            <select class="selectpicker show-tick form-control <?php echo e($errors->has('user_id') ? 'form-error' : ''); ?>" data-size="5" data-live-search="true" id="user-id" name="user_id">
              <?php
                $selected_id = $errors->any() ? old('user_id') : Auth::user()->id;
              ?>
              <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value='<?php echo e($user->id); ?>' <?php echo e($selected_id == $user->id ? 'selected' : ''); ?>><?php echo e($user->profile->first_name); ?> <?php echo e($user->profile->last_name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="error-input"><?php echo e($errors->first('user_id')); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>
        <button type="submit" class="btn btn-primary btn-gradient btn-submit-form">Salva</button>
      </form>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.db', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/db_views/meeting/create.blade.php ENDPATH**/ ?>