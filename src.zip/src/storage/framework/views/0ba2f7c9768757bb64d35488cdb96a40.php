<!-- Navigation -->
<?php
  $url = url()->current();
?>
<nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="dbNav">
    <div class="container d-flex justify-content-between">
      <a class="navbar-brand" href="<?php echo e(route('home', ['loader'=>false])); ?>"><img src="/img/main_home/epordata_logo.png"></a>
      <button class="navbar-toggler navbar-toggler-right" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        Menu
        <i class="fas fa-bars"></i>
      </button>
      <div class="collapse navbar-collapse justify-content-end" id="navbarResponsive">
        <ul class="navbar-nav text-uppercase ml-auto">
          <li class="nav-item">
            <a class="nav-link <?php echo e(strpos($url, 'home') ? 'active' : ''); ?>" href="<?php echo e(route('db_home')); ?>"><i class="fas fa-home fa-lg"></i>Home personale</a>
          </li>
          <?php if(Auth::user()->auth_level == 'Admin'): ?>
            <li class="nav-item">
              <a class="nav-link <?php echo e(strpos($url, 'profile') ? 'active' : ''); ?>" href="<?php echo e(route('profile.index')); ?>">Profili utenti</a>
            </li>
          <?php endif; ?>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle <?php echo e(strpos($url, 'customer') ? 'active' : ''); ?>" href="#" id="customer-dropdown" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Clienti</a>
             <div class="dropdown-menu" aria-labelledby="customer-dropdown">
              <a class="dropdown-item" href="<?php echo e(route('customer.index')); ?>">Tutti</a>
              <a class="dropdown-item" href="<?php echo e(route('customer.index', ['personal'=>true])); ?>">Solo miei</a>
            </div>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo e(strpos($url, 'product') ? 'active' : ''); ?>" href="<?php echo e(route('product.index')); ?>">Prodotti</a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo e(strpos($url, 'provider') ? 'active' : ''); ?>" href="<?php echo e(route('provider.index')); ?>">Fornitori</a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle <?php echo e(strpos($url, 'meeting') ? 'active' : ''); ?>" href="#" id="meeting-dropdown" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Appuntamenti</a>
            <div class="dropdown-menu" aria-labelledby="meeting-dropdown">
              <a class="dropdown-item" href="<?php echo e(route('meeting.index')); ?>">Tutti</a>
              <a class="dropdown-item" href="<?php echo e(route('meeting.index', ['personal'=>true])); ?>">Tutti miei</a>
              <a class="dropdown-item" href="<?php echo e(route('meeting.index', ['future'=>true])); ?>">Tutti futuri</a>
              <a class="dropdown-item" href="<?php echo e(route('meeting.index', ['personal'=>true, 'future'=>true])); ?>">Solo miei e futuri</a>
            </div>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo e(strpos($url, 'lecture') ? 'active' : ''); ?>" href="<?php echo e(route('lecture.index')); ?>">Corsi</a>
          </li>
          <?php if(auth()->guard()->check()): ?>
          <li class="nav-item dropdown notif">
            <a class="nav-link dropdown-toggle" href="#" id="auth-dropdown" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <mark></mark>
                <?php if(Auth::user()->auth_level == 'Admin'): ?>
                  <i class="fas fa-crown fa-lg"></i>
                <?php else: ?>
                  <i class="fas fa-user fa-lg"></i>
                <?php endif; ?>
                <?php echo e(Auth::user()->name); ?>

            </a>
            <div class="dropdown-menu" aria-labelledby="auth-dropdown">
              <a class="dropdown-item" href="<?php echo e(route('profile.show', Auth::user()->profile)); ?>">Il mio profilo</a>
              <?php if(Auth::user()->auth_level == 'Admin' || Auth::user()->auth_level == 'Operator'): ?>
                <?php if(Route::has('register')): ?>
                  <a class="dropdown-item" href="<?php echo e(route('register')); ?>">Aggiungi utente</a>
                <?php endif; ?>
                <a class="dropdown-item" href="<?php echo e(route('user.index')); ?>">Rimuovi/modifica utente</a>
              <?php endif; ?>
                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                  <?php echo e(__('Logout')); ?> <i class="fas fa-sign-out-alt"></i>
              </a>
              <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
              </form>
            </div>
          </li>
          <?php endif; ?>
        </ul>
      </div>
    </div>
  </nav>
<?php /**PATH /var/www/html/resources/views/db_views/shared/db-nav.blade.php ENDPATH**/ ?>