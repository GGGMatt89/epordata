<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="EPORDATA sas website">
    <meta name="author" content="Mattia Fontana @ Flumens Techlab">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Epordata SAS')); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/db_app.js'); ?>

    
    <link href='/lib/fullcalendar/core/main.css' rel='stylesheet' />
    <link href='/lib/fullcalendar/daygrid/main.css' rel='stylesheet' />
    <link href='/lib/fullcalendar/timegrid/main.css' rel='stylesheet' />
    <link href='/lib/fullcalendar/bootstrap/main.css' rel='stylesheet' />
    <script src='/lib/fullcalendar/core/main.js'></script>
    <script src='/lib/fullcalendar/daygrid/main.js'></script>
    <script src='/lib/fullcalendar/timegrid/main.js'></script>
    <script src='/lib/fullcalendar/bootstrap/main.js'></script>
    <script src='/lib/fullcalendar/core/locales/es.js'></script>

    <!-- FAVICON -->
    <link rel="shortcut icon" type="image/png" href="/img/main_home/epordata.ico"/>
</head>

<body id="page-top">


    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- SCRIPT SECTION  -->
  <!-- Plugin JavaScript -->
  <script type="module" src="/lib/jquery-easing/jquery.easing.min.js"></script>
  
  <script src="/js/db_main.js"></script>

  
    
    <script src="/js/clock.js" defer></script>
    <script src="/js/delete_confirmation.js"></script>

    
    <?php echo $__env->make('db_views.shared.db-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <div class='main-container' id='main-container'>
        <div class='row'>
            <div class='col-sm-12 col-lg-10'>
                <?php echo $__env->yieldContent('main_content_page'); ?>
            </div>
            <div class='col-sm-4 col-lg-2'>
                <?php echo $__env->make('db_views.shared.db-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div> 
    </div>

    

    
    <?php echo $__env->make('shared_views.footerbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  </body>

</html>
<?php /**PATH /var/www/html/resources/views/layouts/db.blade.php ENDPATH**/ ?>