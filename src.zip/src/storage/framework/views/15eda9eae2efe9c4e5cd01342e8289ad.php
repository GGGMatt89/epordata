<script src="/js/home_calendar.js"></script>
<?php if(count($users) > 1): ?>
    <div class='form-row items-center'>
      <div class="form-group col-12 col-md-6">
        <label class='db_form_label' for="user_id">Appuntamenti di: </label>
        <select class="selectpicker show-tick  form-control <?php echo e($errors->has('user_id') ? 'form-error' : ''); ?>" data-size="5" name="user_id" id="user_id" value="<?php echo e(old('user_id')); ?>" data-live-search="true">
          <option value=' ' selected>Tutti</option>
          <option data-divider="true"></option>
          <?php
            $selected_prof = $errors->any() ? old('user_id') : Auth::user()->id;
          ?>
          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value='<?php echo e($user->id); ?>' <?php echo e($selected_prof == $user->id ? 'selected' : ''); ?>><?php echo e($user -> profile -> first_name); ?> <?php echo e($user -> profile -> last_name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <p class="error-input"><?php echo e($errors->first('user_id')); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
    </div>
<?php else: ?>
    <?php
        $selected_prof = Auth::user()->id;
    ?>
<?php endif; ?>

<div class='justify-content-center' id='calendar' style='width: 100%; margin-top: 20px'>
</div>

<script>
    let array_events = <?php echo json_encode($meetings, 15, 512) ?>;
    let today = new Date();
    let feat = 'future';
    let setId = '<?php echo e($selected_prof); ?>';
    // let events = prepareMeetings(array_events, col_obj, today);
    // let dd = String(today.getDate()).padStart(2, '0');
    // let mm = String(today.getMonth() + 1).padStart(2, '0');
    // let yyyy = today.getFullYear();
    // today = yyyy + '-' + mm + '-' + dd;
    let calendarEl = document.getElementById('calendar');
    let calendar = createCalendar(calendarEl, col_obj);
    document.addEventListener('DOMContentLoaded', calendar.render());
    let selection = document.getElementById('user_id');
    if(selection){
        selection.addEventListener('change', (event) => calendar.refetchEvents());
    }
</script>
<?php /**PATH /var/www/html/resources/views/db_views/user/db-user-home.blade.php ENDPATH**/ ?>