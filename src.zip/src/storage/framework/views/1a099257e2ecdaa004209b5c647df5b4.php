<?php $__env->startSection('main_content_page'); ?>
<div class='row'>
        <div class='col-12'>
            <h3 class='section_title'>Lista utenti registrati</h3>
            <hr class='styled-hr'>
        </div>
    </div>
                <div class='row'>
                    <div class='col-2'>
                        <a role="button" class="btn btn-dark-blue btn-tooltip" data-toggle="tooltip" data-placement="bottom" title="Aggiungi utente" href="<?php echo e(route('register')); ?>"><i class="fas fa-plus"></i></a>
                    </div>
                </div>
                <div class='table-responsive' id='users_table' style='padding-top: 20px;'>
                    <table class="table table-hover">
                    <thead>
                        <tr class="bg-table-header">
                            <th scope="col">ID</th>
                            <th scope="col">Nome</th>
                            <th scope="col">Ruolo</th>
                            <th scope="col">Email</th>
                            <th scope="col"></th>
                            <th scope="col"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($user -> id); ?></th>
                            <td><?php echo e($user -> name); ?></td>
                            <td><?php echo e($user -> auth_level); ?></td>
                            <td><?php echo e($user -> email); ?></td>
                            <td><a class = "btn btn-dark-blue-out btn-tooltip" data-toggle="tooltip" data-placement="bottom" title="Modifica" href = "<?php echo e(route ('user.edit', $user->id )); ?>"><i class="far fa-edit"></i></a></td>
                            <td><form class='delete_form' id='<?php echo e($user->id); ?>_delete_form' action="<?php echo e(route('user.delete', $user->id)); ?>" method="post">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button class="btn btn-primary btn-tooltip" data-toggle="tooltip" data-placement="bottom" title="Elimina" type="button" onclick='deleteEntry(<?php echo e($user->id); ?>)'><i class="far fa-trash-alt"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    </table>
                </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.db', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/db_views/user/index.blade.php ENDPATH**/ ?>