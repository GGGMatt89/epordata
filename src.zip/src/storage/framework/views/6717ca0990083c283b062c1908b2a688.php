<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="EPORDATA sas website">
    <meta name="author" content="Mattia Fontana">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'EpordataSAS')); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
    

    
        <link href="/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    
        <link href="/lib/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
        <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
        <link href='https://fonts.googleapis.com/css?family=Kaushan+Script' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700' rel='stylesheet' type='text/css'>
        <link href="https://fonts.googleapis.com/css?family=Montserrat+Subrayada&display=swap" rel="stylesheet">

    
        
        <link href='/lib/fullcalendar/core/main.css' rel='stylesheet' />
        <link href='/lib/fullcalendar/daygrid/main.css' rel='stylesheet' />
        <link href='/lib/fullcalendar/bootstrap/main.css' rel='stylesheet' />
        
        <script src='/lib/fullcalendar/core/main.js'></script>
        <script src='/lib/fullcalendar/daygrid/main.js'></script>
        <script src='/lib/fullcalendar/bootstrap/main.js'></script>
        <script src='/lib/fullcalendar/core/locales/es.js'></script>

    
        <link rel="stylesheet" href="/lib/animate-css/animate.css">
    
        <script src="/lib/sweetAlert2/sweetalert2.all.min.js"></script>
        <link rel="stylesheet" href="/lib/sweetAlert2/sweetalert2.min.css">

    
      <link href="/lib/please-wait/please-wait.css" rel="stylesheet">

    
      <link href="/css/agency.css" rel="stylesheet">

    
    
      <script src="/lib/jquery/jquery.min.js"></script>
      

    
      <script src="/lib/jquery-easing/jquery.easing.min.js"></script>
      <script type="text/javascript" src="/lib/please-wait/please-wait.min.js"></script>

      <?php echo app('Illuminate\Foundation\Vite')('resources/js/agency.js'); ?>

    
      <link rel="shortcut icon" type="image/png" href="/img/main_home/epordata.ico"/>
</head>

<body id="page-top">
  <?php echo $__env->yieldContent('main_content'); ?>
  

  
      
    
      <script src="/js/jqBootstrapValidation.js"></script>
      <script src="/js/contact_me.js"></script>

    
      <script src="/js/calendar.js"></script>
      <script src="/js/directContact.js"></script>

</body>

</html>
<?php /**PATH /Volumes/MattWorkSSD/FLUMENS_techlab/websites/EPORDATA_webapp/epordata/epordataUPGRADE/epordataWebApp/resources/views/layouts/main.blade.php ENDPATH**/ ?>