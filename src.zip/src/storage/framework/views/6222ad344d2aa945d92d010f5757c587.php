<?php $__env->startSection('main_content_page'); ?>
  <div class='row'>
    <div class='col-12'>
      <h3 class='section_title'>Modifica profilo</h3>
      <hr class='styled-hr'>
      <form method='POST' action='<?php echo e(route("profile.update", $profile->id)); ?>' enctype='multipart/form-data'>
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <input name="user_id" id="user_id" type="hidden" value=<?php echo e($profile->user_id); ?>>
        <div class='form-row'>
          <div class="form-group col-6">
            <label class='db_form_label' for="first_name">Nome</label>
            <input type="text" class="form-control <?php echo e($errors->has('first_name') ? 'form-error' : ''); ?>" name="first_name" id="first_name" placeholder="Nome" value=<?php echo e($errors->any() ? old('first_name') : $profile->first_name); ?>>
            <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="error-input"><?php echo e($errors->first('first_name')); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="form-group col-6">
            <label class='db_form_label' for="last_name">Cognome</label>
            <input type="text" class="form-control <?php echo e($errors->has('last_name') ? 'form-error' : ''); ?>" name="last_name" id="last_name" placeholder="Cognome" value="<?php echo e($errors->any() ? old('last_name') : $profile->last_name); ?>">
            <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="error-input"><?php echo e($errors->first('last_name')); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>
        <div class='form-row'>
          <div class="form-group col-6">
            <label class='db_form_label' for="birth_date">Data di nascita</label>
            <input type="date" class="form-control <?php echo e($errors->has('birth_date') ? 'form-error' : ''); ?>" name="birth_date" id="birth_date" placeholder="Data di nascita" value=<?php echo e($errors->any() ? old('birth_date') : $profile->birth_date); ?>>
            <?php $__errorArgs = ['birth_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="error-input"><?php echo e($errors->first('birth_date')); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="form-group col-6">
            <label class='db_form_label' for="tax_code">Codice fiscale</label>
            <input type="text" class="form-control <?php echo e($errors->has('tax_code') ? 'form-error' : ''); ?>" name="tax_code" id="tax_code" placeholder="Codice fiscale" value=<?php echo e($errors->any() ? old('tax_code') : $profile->tax_code); ?>>
            <?php $__errorArgs = ['tax_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="error-input"><?php echo e($errors->first('tax_code')); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>
        <div class='form-row'>
          <div class="form-group col-6">
            <label class='db_form_label' for="res_address">Indirizzo</label>
            <input type="text" class="form-control <?php echo e($errors->has('res_address') ? 'form-error' : ''); ?>" name="res_address" id="res_address" placeholder="Indirizzo" value="<?php echo e($errors->any() ? old('res_address') : $profile->res_address); ?>">
            <?php $__errorArgs = ['res_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="error-input"><?php echo e($errors->first('res_address')); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="form-group col-3">
            <label class='db_form_label' for="post_code">Codice postale</label>
            <input type="text" class="form-control <?php echo e($errors->has('post_code') ? 'form-error' : ''); ?>" name="post_code" id="post_code" placeholder="Codice postale" value=<?php echo e($errors->any() ? old('post_code') : $profile->post_code); ?>>
            <?php $__errorArgs = ['post_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="error-input"><?php echo e($errors->first('post_code')); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="form-group col-3">
            <label class='db_form_label' for="res_city">Città</label>
            <input type="text" class="form-control <?php echo e($errors->has('res_city') ? 'form-error' : ''); ?>" name="res_city" id="res_city" placeholder="Città" value="<?php echo e($errors->any() ? old('res_city') : $profile->res_city); ?>">
            <?php $__errorArgs = ['res_city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="error-input"><?php echo e($errors->first('res_city')); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>
        <div class='form-row'>
          <div class="form-group col-8">
            <label class='db_form_label' for="mobile_phone">Cellulare</label>
            <input type="text" class="form-control <?php echo e($errors->has('mobile_phone') ? 'form-error' : ''); ?>" name="mobile_phone" id="mobile_phone" placeholder="Cellulare" value="<?php echo e($errors->any() ? old('mobile_phone') : $profile->mobile_phone); ?>">
            <?php $__errorArgs = ['mobile_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="error-input"><?php echo e($errors->first('mobile_phone')); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="form-group col-4">
            <label class='db_form_label' for="area">Area</label>
            <input type="text" class="form-control <?php echo e($errors->has('area') ? 'form-error' : ''); ?>" name="area" id="area" placeholder="Area di competenza" value="<?php echo e($errors->any() ? old('area') : $profile->area); ?>">
            <?php $__errorArgs = ['area'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="error-input"><?php echo e($errors->first('area')); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>
        <div class='form-row' style="margin-top: 20px;">
          <div class="form-group col-9">
            <label class='db_form_label input-file-label' for="image_path"><i class="fas fa-file-upload"></i> Carica immagine</label>
            <input type="file" class="input-file form-control" <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> name="image" id="image_path">
              <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="error-input"><?php echo e($errors->first('image')); ?></p>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-3 d-flex justify-content-center">
            <div class="team-member">
              <img id="previewHolder" class="mx-auto rounded-circle" src=<?php echo e($profile->image); ?> alt="<?php echo e($profile->first_name); ?> <?php echo e($profile->last_name); ?>"/>
            </div>
          </div>
        </div>
        <button type="submit" class="btn btn-primary btn-gradient btn-submit-form">Salva modifiche</button>
      </form>
    </div>
  </div>
<script type="module" src="/js/image_preview.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.db', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/db_views/profile/edit.blade.php ENDPATH**/ ?>