<!-- News -->
<section class="bg-light page-section" id="products">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-12 text-center">
          <h2 class="section-heading text-uppercase">News</h2>
          <h3 class="section-subheading text-muted">Tutte le ultime novità sui prodotti e sulle attività del gruppo.</h3>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-6 col-md-6 col-12 mx-auto">
          <?php if( count($news_all) == 0 ): ?>
            <div class="text-center">
              <h4> <a href="#contact" class="js-scroll-trigger">Contattaci</a> per restare costantemente aggiornato! </h4>
            </div>
          <?php else: ?>
            <div id="carouselNews" class="carousel slide offers-carousel" data-ride="carousel" data-interval="2000">
              <ol class="carousel-indicators">
                <?php $__currentLoopData = $news_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li data-target="#carouselNews" data-slide-to="<?php echo e($loop->index); ?>" class="<?php echo e($loop->first ? 'active' : ''); ?>"></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ol>
              <div class="carousel-inner">
                <?php $__currentLoopData = $news_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="carousel-item <?php echo e($loop->first ? 'active' : ''); ?>">
                      <img class="d-block w-100 my-auto" src=<?php echo e($news->image_path); ?> alt="<?php echo e($news->preview_title); ?>">
                      <div class="carousel-caption">
                        <h5><?php echo e($news->preview_title); ?></h5>
                        <p class='d-none d-lg-block'><?php echo e($news->preview_subtitle); ?></p>
                        <a class="btn btn-primary btn-to-modal text-uppercase" data-toggle="modal" href="#news<?php echo e($news->id); ?>Modal">Scopri di più</a>
                      </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              <?php if(count($news_all) > 1): ?>
              <a class="carousel-control-prev" href="#carouselNews" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Precedente</span>
              </a>
              <a class="carousel-control-next" href="#carouselNews" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Successivo</span>
              </a>
              <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
        <div class="col-lg-4 col-md-4 col-12 mx-auto overflow-auto " style='max-height: 70vh'>
          <?php $__currentLoopData = $news_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-12 d-none d-lg-block">
              <h5><i class="far fa-newspaper"></i> <a class='news_title_link' data-toggle="modal" href="#news<?php echo e($news->id); ?>Modal"><?php echo e($news->preview_title); ?></a></h5>
              <hr width="90%" size="5" align="center">
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    </div>
  </section>


  <!-- Modali NEWS -->
  <?php $__currentLoopData = $news_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="products-modal modal fade" id="news<?php echo e($news->id); ?>Modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="close-modal" data-dismiss="modal">
          <div class="lr">
            <div class="rl"></div>
          </div>
        </div>
        <div class="container">
          <div class="row">
            <div class="col-lg-8 mx-auto">
              <div class="modal-body">
                <!-- News Details Go Here -->
                <h2 class="text-uppercase"><?php echo e($news->title); ?></h2>
                <p class="item-intro text-uppercase"><?php echo e($news->excerpt); ?></p>
                <img class="img-fluid d-block mx-auto my-auto" src=<?php echo e($news->image_path); ?> alt="<?php echo e($news->preview_title); ?>">
                <p class="item-text"><?php echo e($news->body); ?></p>
                <ul class="list-inline">
                  <li>Pubblicata il : <?php echo e(Carbon\Carbon::parse($news -> date) -> toDateString()); ?></li>
                  <li>Categoria: Novità</li>
                </ul>
                <button class="btn btn-primary" data-dismiss="modal" type="button">
                  <i class="fas fa-times"></i>
                  Chiudi</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH /Volumes/MattWorkSSD/FLUMENS_techlab/websites/EPORDATA_webapp/epordata/epordataUPGRADE/epordataWebApp/resources/views/home_views/body-sec-news.blade.php ENDPATH**/ ?>