<!-- Navigation -->
<nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
    <div class="container d-flex justify-content-between">
        <a class="navbar-brand" href="<?php echo e(route('home', ['loader'=>false])); ?>"><img src="/img/main_home/epordata_logo.png"></a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          Menu
          <i class="fas fa-bars"></i>
        </button>
      <div class="collapse navbar-collapse justify-content-end" id="navbarResponsive">
        <ul class="navbar-nav text-uppercase">
          <li class="nav-item">
            <a class="nav-link" href="#services">Servizi</a>
          </li>
          
          <li class="nav-item">
            <a class="nav-link" href="#history">Chi siamo</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#team">Il team</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#contact">Contattaci</a>
          </li>
          <?php if(Route::has('login')): ?>
              <?php if(auth()->guard()->check()): ?>
              <li class="nav-item dropdown notif">
                
                <a class="nav-link dropdown-toggle user-link" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  <mark></mark>
                  <span class="notification-badge  <?php echo e($Nmeeting>0 ? 'd-block' : 'd-none'); ?>"><?php echo e($Nmeeting); ?></span>
                  <span>
                  <?php if(Auth::user()->auth_level == 'Admin'): ?>
                    <i class="fas fa-crown fa-lg"></i>
                  <?php else: ?>
                    <i class="fas fa-user fa-lg"></i>
                  <?php endif; ?>
                  <?php echo e(Auth::user()->name); ?>

                  </span>
                </a>
                <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                  <li><a class="dropdown-item" href="<?php echo e(route('db_home')); ?>">Gestionale</a></li>
                  
                  <li><a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                      onclick="event.preventDefault();
                      document.getElementById('logout-form').submit();">
                      <?php echo e(__('Logout')); ?> <i class="fas fa-sign-out-alt"></i>
                  </a>
                  <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                      <?php echo csrf_field(); ?>
                  </form></li>
                </ul>
              </li>
              <?php else: ?>
              <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('login')); ?>" ><span><i class="fas fa-user fa-lg"></i></span>Area privata</a>
                  
                  
              </li>
              <?php endif; ?>
            </li>
          <?php endif; ?>
        </ul>
      </div>
    </div>
  </nav>
<?php /**PATH /var/www/html/resources/views/home_views/main-nav.blade.php ENDPATH**/ ?>