<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="EPORDATA sas website">
    <meta name="author" content="Mattia Fontana @ Flumens Techlab">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Epordata SAS')); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>

    
      
      

    
      <link rel="shortcut icon" type="image/png" href="/img/main_home/epordata.ico"/>
</head>

<body id="page-top">
  <?php echo $__env->yieldContent('main_content'); ?>
  <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
      <script type="module" src="/js/jqBootstrapValidation.js"></script>
      <script type="module" src="/js/contact_me.js"></script>

    
      

</body>

</html>
<?php /**PATH /var/www/html/resources/views/layouts/main.blade.php ENDPATH**/ ?>