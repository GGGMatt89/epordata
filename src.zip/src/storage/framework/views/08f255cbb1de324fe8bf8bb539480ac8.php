<?php $__env->startSection('main_content_page'); ?>
    <div class="jumbotron" style="width: 80%; margin:auto; padding: 10px;">
        <div class="container">
            <div class='row'>
                <div class="col-12 col-lg-10">
                    <h3 class="section_title"><?php echo e($profile->first_name); ?> <?php echo e($profile->last_name); ?> </h3>
                </div>
                <div class='col-1 col-lg-1'>
                   <a role="button" class="btn btn-dark-blue-out btn-tooltip" data-toggle="tooltip" data-placement="bottom" title="Modifica" href="<?php echo e(route('profile.edit', $profile->id)); ?>"><i class="far fa-edit"></i></a>
                </div>
                <div class='col-1 col-lg-1'>
                   <a role="button" class="btn btn-dark-green-out btn-tooltip" data-toggle="tooltip" data-placement="bottom" title="Modifica credenziali" href="<?php echo e(route('user.editLimit', $profile->user->id)); ?>"><i class="fas fa-user-edit"></i></a>
                </div>
            </div>
            <div class='row'>
                <div class="form-group col-12 col-lg-6 my-auto">
                    <div class="team-member">
                        <img class="mx-auto rounded-circle" src=<?php echo e($profile->image); ?> alt="<?php echo e($profile->first_name); ?> <?php echo e($profile->last_name); ?>">
                    </div>
                </div>
                <div class="form-group col-12 col-lg-6">
                    <p class="lead lead-in">ID:</p>
                    <p class="lead"><?php echo e($profile->user->name); ?></p>
                    <p class="lead lead-in">Email:</p>
                    <p class="lead"><?php echo e($profile->user->email); ?></p>
                </div>
            </div>
            <div class='row d-flex justify-content-center'>
                <hr class='show-sep'>
            </div>
            <div class='row'>
                <div class="form-group col-12 col-lg-2">
                    <p class="lead lead-in">Indirizzo:</p>
                </div>
                <div class="form-group col-12 col-lg-10">
                    <p class="lead"><?php echo e($profile->res_address); ?>, <?php echo e($profile->post_code); ?>, <?php echo e($profile->res_city); ?></p>
                </div>
            </div>
            <div class='row'>
                <div class="form-group col-12 col-lg-2">
                    <p class="lead lead-in">Codice fiscale:</p>
                </div>
                <div class="form-group col-12 col-lg-10">
                    <p class="lead"><?php echo e($profile->tax_code); ?></p>
                </div>
            </div>
            <div class='row'>
                <div class="form-group col-12 col-lg-2">
                    <p class="lead lead-in">Cellulare:</p>
                </div>
                <div class="form-group col-12 col-lg-4">
                    <p class="lead"><?php echo e($profile->mobile_phone); ?></p>
                </div>
                <div class="form-group col-12 col-lg-2">
                    <p class="lead lead-in">Area:</p>
                </div>
                <div class="form-group col-12 col-lg-4">
                    <p class="lead"><?php echo e($profile->area); ?></p>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.db', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/db_views/profile/show.blade.php ENDPATH**/ ?>