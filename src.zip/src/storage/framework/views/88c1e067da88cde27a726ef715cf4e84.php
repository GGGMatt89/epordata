<?php $__env->startSection('main_content_page'); ?>
    <div class='row'>
        <div class='col-12'>
            <h3 class='section_title'>Lista corsi/seminari</h3>
            <hr class='styled-hr'>
        </div>
    </div>
    <div class='row'>
        <div class='col-sm-2 col-md-1'>
            <a role="button" class="btn btn-dark-blue btn-tooltip" data-toggle="tooltip" data-placement="bottom" title="Aggiungi" href="<?php echo e(route('lecture.create')); ?>"><i class="fas fa-plus"></i></a>
        </div>
    </div>
    <div class='table-responsive' id='lectures_table'>
        <table class="table table-hover align-middle">
        <thead>
            <tr class="bg-table-header">
            <th scope="col">Titolo</th>
            <th scope="col">Da</th>
            <th scope="col">A</th>
            <th scope="col">Luogo</th>
            <th scope="col">C.F.P.</th>
            <th scope="col"> </th>
            <th scope="col"> </th>
            <th scope="col"> </th>
            <th scope="col"> </th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $lectures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lecture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                <th scope="row"><?php echo e($lecture->title); ?></th>
                <td><?php echo e(Carbon\Carbon::parse($lecture->beginning)->format('d-m-Y')); ?> <br> <?php echo e(Carbon\Carbon::parse($lecture->beginning)->format('H:i')); ?></td>
                <td><?php echo e(Carbon\Carbon::parse($lecture->end)->format('d-m-Y')); ?> <br> <?php echo e(Carbon\Carbon::parse($lecture->end)->format('H:i')); ?></td>
                <td><?php echo e($lecture -> place); ?></td>
                <td><?php echo e($lecture -> cfp); ?></td>
                <td><a class = "btn btn-dark-blue btn-tooltip" data-toggle="tooltip" data-placement="bottom" title="Dettagli" href = "<?php echo e(route ('lecture.show', $lecture -> id )); ?>"><i class="far fa-eye"></i></a></td>
                <td><a class = "btn btn-dark-blue-out  btn-tooltip" data-toggle="tooltip" data-placement="bottom" title="Modifica" href = "<?php echo e(route ('lecture.edit', $lecture -> id )); ?>"><i class="far fa-edit"></i></a></td>
                <td><a class = "btn btn-dark-red-out btn-tooltip" data-toggle="tooltip" data-placement="bottom" title="Aggiungi partecipante" href = "<?php echo e(route ('participant.create', ["lecture_id"=>$lecture->id])); ?>"><i class="fas fa-chalkboard-teacher"></i></a></td>
                <td><form class='delete_form' id='<?php echo e($lecture->id); ?>_delete_form' action="<?php echo e(route('lecture.delete', $lecture->id)); ?>" method="post">
                        <?php echo method_field('DELETE'); ?>
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-primary btn-tooltip" data-toggle="tooltip" data-placement="bottom" title="Elimina" type="button" onclick='deleteEntry(<?php echo e($lecture->id); ?>)'><i class="far fa-trash-alt"></i></button>
                    </form>
                </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  <tr>
                      <th scope="row" colspan="9">Nessun corso/seminario</th>
                  </tr>
              <?php endif; ?>
        </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.db', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/db_views/lecture/index.blade.php ENDPATH**/ ?>