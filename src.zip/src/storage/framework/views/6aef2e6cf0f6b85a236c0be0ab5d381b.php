<?php $__env->startSection('main_content_page'); ?>
<script src="/js/forms_handling_product.js"></script>
  <div class='row'>
    <div class='col-12'>
      <h3 class='section_title'>Nuovo prodotto</h3>
      <hr class='styled-hr'>
      <form method='POST' action='<?php echo e(route("product.store")); ?>'>
        <?php echo csrf_field(); ?>
        <input name="provider_id" id="provider-id" type="hidden">
        <div class='form-row'>
          <div class="form-group col-12">
            <label class='db_form_label' for="name">Nome</label>
            <input type="text" class="form-control <?php echo e($errors->has('name') ? 'form-error' : ''); ?>" name="name" id="name" value="<?php echo e(old('name')); ?>" placeholder="Nome">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="error-input"><?php echo e($errors->first('name')); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="form-group col-12">
            <label class='db_form_label' for="code">Codice</label>
            <input type="text" class="form-control <?php echo e($errors->has('code') ? 'form-error' : ''); ?>" name="code" id="code" value="<?php echo e(old('code')); ?>" placeholder="Codice prodotto">
            <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="error-input"><?php echo e($errors->first('code')); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>
        <div class='form-row'>
          <div class="form-group col-6">
            <label class='db_form_label' for="type">Tipo</label>
            <select class="selectpicker show-tick form-control <?php echo e($errors->has('type') ? 'form-error' : ''); ?>" data-size="5" id="type" name="type" value="<?php echo e(old('type')); ?>">
              <option value=''>Seleziona tipo prodotto</option>
              <option data-divider="true"></option>
              <?php
                $selected_type = $errors->any() ? old('type') : '';
              ?>
              <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value=<?php echo e($type); ?> <?php echo e($selected_type == $type ? 'selected' : ''); ?>><?php echo e($type); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="error-input"><?php echo e($errors->first('type')); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="form-group col-6">
            <label class='db_form_label' for="category">Categoria</label>
            <select class="selectpicker show-tick form-control <?php echo e($errors->has('category') ? 'form-error' : ''); ?>" data-size="5" name="category" id="category" value="<?php echo e(old('category')); ?>" placeholder="Categoria prodotto">
              <option value=''>Seleziona categoria prodotto</option>
              <option data-divider="true"></option>
              <?php
                $selected_cat = $errors->any() ? old('category') : '';
              ?>
              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value='<?php echo e($category); ?>' <?php echo e($selected_cat == $category ? 'selected' : ''); ?>><?php echo e($category); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="error-input"><?php echo e($errors->first('category')); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group col-12">
            <label class='db_form_label' for="prov-select">Fornitore</label>
            <select class="selectpicker show-tick form-control" id="prov-select" name="provider_id" data-size="5" data-live-search="true" >
              <option value=''>Seleziona fornitore o aggiungilo manualmente</option>
              <option data-divider="true"></option>
              <?php
              $selected_prov = $errors->any() ? old('provider_id') : '';
              ?>
              <?php $__currentLoopData = $providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value='<?php echo e($provider->id); ?>' <?php echo e($selected_prov == $provider->id ? 'selected' : ''); ?>><?php echo e($provider->bus_name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
        </div>
        <div class='form-row'>
          <div class="form-group col-sm-12 col-md-6">
            <label class='db_form_label' for="provider_name">Nome fornitore</label>
            <input type="text" class="form-control <?php echo e($errors->has('provider_name') ? 'form-error' : ''); ?>" name="provider_name" id="provider-name" value="<?php echo e(old('provider_name')); ?>" placeholder="Nome">
            <?php $__errorArgs = ['provider_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="error-input"><?php echo e($errors->first('provider_name')); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>
        <button type="submit" class="btn btn-primary btn-gradient btn-submit-form">Salva</button>
      </form>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.db', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/db_views/product/create.blade.php ENDPATH**/ ?>