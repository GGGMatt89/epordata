@extends ('layouts.db')

@section ('main_content_page')
    @include('db_views.user.db-user-home')
@endsection
