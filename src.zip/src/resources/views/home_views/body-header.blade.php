<!-- Header -->
<header class="masthead">
  <div class="container">
    <div class="intro-text">
      <div>
        <img id="logo_big" src="/img/main_home/epordata_logo.png" class="logo_img img-fluid animate__animated animate__heartBeat">
      </div>
      <div class="intro-lead-in text-uppercase">
        Servizi per professionisti e imprese
      </div>
      <div class="intro-heading text-uppercase"></div>
        <a class="btn btn-primary btn-xl text-uppercase js-scroll-trigger" href="#services">Scopri di più</a>
      </div>
  </div>
</header>
