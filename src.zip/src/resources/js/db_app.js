// STYLING
import '../sass/layouts/custom_db.scss';

//selectpicker for bootstrap5
import 'bootstrap-select/sass/bootstrap-select.scss';
import 'bootstrap-select';
