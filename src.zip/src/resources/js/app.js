// STYLING
import '../sass/app.scss';


import './bootstrap';

// JQUERY
import jQuery from 'jquery';
window.$ = window.jQuery = jQuery;

// TEMPLATE
import './template/agency';

// import Alpine from 'alpinejs';

// window.Alpine = Alpine;

// Alpine.start();

// external libraries
import Swal from 'sweetalert2';
window.Swal = Swal;
import 'animate.css';
